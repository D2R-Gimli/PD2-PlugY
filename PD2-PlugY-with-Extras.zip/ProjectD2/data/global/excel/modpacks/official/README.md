### official

* Updated: Season 7 (patch 4)

Includes the official PD2 files without any modifications (for reference)

For information about how you can generate these files yourself, see the main [README](https://github.com/BetweenWalls/PD2-Singleplayer#modification).

For explanations of what each file includes and an introduction to text modding, see the Phrozen Keep's [file guide](https://d2mods.info/forum/viewtopic.php?f=4&t=34455).