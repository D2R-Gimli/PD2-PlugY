### Archived Modpacks
The folders in this directory each correspond to a separate text-based modpack for PD2, with the files of each 
modpack being the text files that would normally appear in the folder "Diablo II\ProjectD2\data\global\excel".

Each modpack has a "README" file that describes the modifications it makes.

The modpacks here are from previous seasons and likely won't function properly in later seasons.

See the above folder for more information about modpacks.