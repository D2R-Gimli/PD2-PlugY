### s7_crazy_drops

* Updated: Season 7 (patch 3)
* Author: crazyinside87

Discussion thread: https://www.reddit.com/r/ProjectDiablo2/comments/139e009/s7_single_player_mod/

Changes made:
* No drop disabled - every monster will drop something
* High runes increased by 5x
* Uniques and sets increased by 2x
* WSS greatly increased… because it’s fun to slam
* Puzzleboxes increased by 5x
* Grand charms chance to roll skills increased and can now roll either 1 or 2 to skills.
* Rainbow facets changed from 3%-5% to 5%-10%
* Teleport damage reduction removed, also can teleport in town
* Enigma blink charges changed from 5 to 50
* Spirit all skills changed from 1 to 2
* Monster density increases by 1.5x in Cows, Pits, Chaos sanctuary
* Puzzle boxes now always grant max sockets (up to 6 sockets for 2-handed weapon and 4 sockets for other items)

If you want no immunes, use the MonStats.txt file. Otherwise, ignore it.