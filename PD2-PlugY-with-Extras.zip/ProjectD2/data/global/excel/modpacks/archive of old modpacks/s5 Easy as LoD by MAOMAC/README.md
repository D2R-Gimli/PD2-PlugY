### Easy as LoD

* Updated: Season 5
* Author: MAOMAC

This modpack is also published here with additional info: https://www.moddb.com/mods/easy-as-lod-direct-txt-mod-for-a-mod-project-diablo-2


I made this small SP mod to Project Diablo 2 (Season 5 {currently Patch #8}) because i think balance in PD2 is ...not fun for me.
D2 for me (LoD and PoD) is the game where i can relax farming monsters and content doesn't require me
to be a mechanical GOD to kill a monster (Diablo Clone and RATHMA are WAY too hard for my old slow hands)

Also what is up with these items that have no real chance to drop? Unlimited key, mirror and ethVIAL?
it feels bad knowing there is this item that can do cool stuff but the chance to find it is like 1/infinity
I BUFFED DROPRATE of those items to ZOD runes. Still very rare but now they actually exist.
Corruption chances not evenly distributed is another thing i don't like. I prefer PoD system.

Dmg. If you compare dmg in PD2 and in LoD/PoD you will see that it was nerfed almost everywhere.
You deal from 2x as much to even 4x as much dmg in LoD/PoD.


so my changes:

'prime evil' stat removed from all monsters

	(minions and mercs are way to squishy vs bosses)

monster HP reduced by 50%

	(we deal way to little dmg compared to what we can do in LoD and/or PoD, even with this "2x damage" buff
	you still deal more in LoD/PoD {if you compare unmodded PD2 VS LoD/PoD it's usually 2x-3x and sometimes even 4x (lightning fury)}
	this also "nerfs" revives, BUT I COUNTER THAT with +100% HP buff to the skill (not visible in description, basically vs normal content
	revives are as tanky as in unmodded PD2, and vs bosses they are 4x as tanky because of prime evil stat being removed,
	revives are so squishy vs uber bosses in PD2 you can't even use them vs diablo clone, they just almost insta die, compare it to vanilla
	D2 where you could summon 20+ revives with GIGA HP buff LOL),
	also necro corpse explosion and assassin death sentry corpse explosion %damage is doubled (still GIGA nerfed compared to vanilla D2,
	for example corpse explosion from 70-120% to 10-20, sure you have corpses on demand with desecrate skill but to match the %dmg
	you have to cast it 6 times and	your curses and infinity don't lower resists like in LoD, AND the area is nerfed too),
	the only downside of 50% monster hp reduction is some monsters that we summon with reanimate in bows and stuff like that have reduced hp as well
	{unless it uses	stats from revive skill but i don't think so},
	this was the best and fastest method to buff our damage x2 for everything,
	another reason why this way is the best is tooltip damage is THE SAME as in unmodded PD2,
	so if you see a build showcase from online you instantly know if you will do more/less damage
	if you decide to change your build/play that online build in this version )

monster and minion crit chance reduced from 5% to 0% (no crit)

	(Also removed that chance from our minions for consistency, they still deal WAY more dmg because of monster HP nerf)
	(monsters with mapmods deal more dmg so i think removing crit is ok)

you can leech from all monsters

	(crushing blow is basically "removed" {it stops working vs bosses when they are below 65% HP}
	attacks need to be rewarded SOMEHOW for the AR req,
	so i decided to make phys attack builds "leech tanks", i think it's a fair buff for crushing blow and life tap "removal" in PD2
	we have this in LoD anyway with draculs grasp we have constant leech on everything and +50LL, this is much weaker than that)

removed Monsters have X% Chance of Open Wounds MAP mod

	(this prefix is so overtuned vs mercs it's probably bugged, REMOVED)

skills that give HP REBALANCED

	(LoD BO was removed and we lost WAY to much HP and mana,
	With these changes + life leech change you actually are rewarded a bit for attack rating requirement and being closer to danger.
	Also i think melee is supposed to be the mega tank, and with PD2 changes to HP bonuses melee feels not fun for me
	without this ranged feels like 100% safer)

	
skill changes:

	barbarian berserk -%defense from -100% to -50%  + added description for -% defense
	( in LoD we can use a SHIELD and still 1 shot monsters, so we lost 75% block and on top of that we eat a -20% phys resist debuff? lMAO
	with only 50% of our defense and -20% PhysResist we still lost a bit of tankiness compared to LoD 75% block )

	BARBARIAN battle cry back at Season 4 DURATION
	( Battle cry duration back at 12 seconds + 0.4 seconds per level from 5 seconds at all levels)

	{ with only 5 seconds there is no point for this to be on CTA for example, because if you want to use it with that item you have to
	switch->cast->swith and THEN do dmg for what.. 4 seconds? and then repeat? not fun.)

	BO changed to: lvl 1 +350 hp , mana +175 (stat/lvl no change) (THIS IS STILL GIGA NERFED
	compared to VANILLA D2 where you get +95%+ to HP and MANA,)
	(barb merc provides same bonus as in unmodded PD2-he uses new lvl 1)


	lycanthropy changed to LoD values ( basically i change hp buff skills so we can
	reach (or almost reach) hp levels of LoD )	

	+20% lvl 1/ +5%/lvlup
	

	OAK SAGE - NO CHANGE - in LoD oak JUST DIES so often i consider it completely different skill so i leave it as is,
	also if i buffed it other spirits would be too weak in comparison

	COMBAT REFLEXES: (this is where i put a lot of old LoD BO for barbarian. i balanced BO+CR around 2kHP base,
	since barb usually has like 2k base,
	{i give more to CR because i had to balance this around barb merc so hes not op},
	you basically can reach almost LoD amount of HP on barb if you max BO and CR but you have to spend 40 skillpoints so this is still a nerf compared to LoD)

	lvl 1 +500 hp and +50hp/lvl
	

	NECRO corpse explosion %dmg buff x2 (from 5-10 to 10-20)
		(buff to make the skill deal 2x damage with endgame gear {like other skills}
		because of reduced monster hp, also makes it better with low +skill,)

	NECRO 'FAKE BUFF' TO REVIVE (I REMOVED 50% OF HP FROM BASE MONSTER STATS, AND THEN ADDED +100% HP BUFF {TO NEW BASE} WHEN REVIVING,
		SO NECRO REVIVES HAVE SAME HP AS IN UNMODDED PD2)

	ASSASSIN death sentry corpse explosion %dmg buff x2 (from 3-5 to 6-10)
		(same reason as necro corpse explosion)

	SORCERESS Energy Shield - synergy from telekinesis back at LoD value (from 225%-100% damage taken, to LoD 200%-75%)
		( just like with skill HP buffs for barbarian and druid - buffing sorceress HP potential to LoD/D2R value )

	AMAZON EVADE and DODGE buff (from 33% at lvl 20 to 50% at lvl 14 ; cap from 40% to 65%)
		{ buffing dodge chances to almost LoD value - we only have 2 skills with dodge instead of 3 so
		we have 50% on 14 instead of 12/7 skill lvl, + we have movement speed and FHR in PD2 }

	ASSASSIN weapon block back at LoD values (from 36% at lvl 10 to 50% at lvl 10)
		  FADE buff to LoD values ( curse reduction and physical resists )
		{ fade and weapon block is basically HP for assassin, instead of huge hp buff we got
		some defensive layers in this class }
	DRUID werewolf +%HP buff back at LoD value (from 0% to +25%)
		werebear +%HP buff back at LoD value (from 0% to +75%)
		{ back to LoD HP value for shapeshift melee druids }

	Barbarian Find item back to LoD values (now same as in Diablo 2 Resurrected)
		{ fun skill, and for me FUN>>balance , imo it's not even op in D2R because we invest
		skillpoints from damage/survivability into just a chance to find something, we could just
		kill another monster - that makes this skill very good only in certain places, like travincal}

	Necromancer bone wall and bone prison delay REMOVED
		{ in LoD we can spam it with no delay ;	i reduced it by 20% only first because i thought
		HP got a big buff - turns out HP is very similar to LoD, so delay is removed }

	Sorceress teleport damage penalty reduced (from 65%-25% to 25%-5%)
		{ in LoD we don't have penalty , i like 25%-5% , it's not so bad with just 1 point
		and can almost remove it when maxed }
	
	werebear maul stun - minimum stun 0.2s->0.4s
		(in LoD it starts at 1.7s and scales UP to 3s+)

	werebear shockwave stun 0.2->0.4s
		{0.2 is nothing, in LoD we perma stun for 10s with shockwave}

	werewolf feral rage life steal x2 + no limit (50% of LoD value)
		+ fixed description/tooltip feral rage bugs of PD2
		(in PD2 you get up to 20 LifeSteal { slvl 35 } description shows 10 max)
		(Life steal is all WW has to survive in melee, no real defense, no real block
		just pure life and Life steal, we have more dmg compared to LoD so i think 50% is ok)

	barbarian war cry stun = 0->0.2 second
		(we deal much more dmg compared to LoD, description says it stuns
		...then why doesn't it stun? fixed)

	barbarian stun skill stun duration increased (LoD warcry stun duration)
		(in LoD we stun just as much but with a spell, here we actually have to hit
		a monster, we can miss, it can be blocked etc.)

	mind blast stun now scales down with levels to a minimum of 0.2s
		( again description says it stuns... and i think scaling down
		is much better instead of dropping from 2 to 0 )

	added duration description (for chill) for ice barrage skill
	added cold lenght description for blizzard

	lightning fury - number of bolts at lvl 1: 10->16
		(still weaker than LoD version, but i think it's ok)

	freeze/chill penalty per difficulty back to LoD/PD2/D2R
	freeze/chill duration on skills rebalanced (delete DifficultyLevels.txt from previous verison-no longer needed)
		( i decided to do it correctly instead of messing with difficulty settings )
		compared to PD2:
			amazon:
				cold arrow from 1s to 8s
					( this is super bugged in PD2, in patch notes and wiki you see it should be 4s,
					but in game it's just 1s ?, value in frames in original file is correct,
					but the game somehow just takes only 1/4 of it? )
					
				ice arrow x2
				freezing arrow x2

			sorceress:
				ice bolt x2
				ice blast x2
				ice barrage from 0+3/lvl frames to 5+5/lvl frames (1s=25frames)
					+added cold length description
				glacial spike x2
				frost nova from 8+0.2s/lvl to 8+0.4s/lvl

			assassin, druid, necromancer, paladin, barbarian:
			no change

	Amazon cold arrow duration description no longer changes depending on difficulty (for consistency with other skills)
		( it was the only damage skill that changed duration description depending on difficulty )

	Necromancer Dim vision duration rebalanced (now 1.6s +0.4s/lvl)
		( in PD2 dim vision duration {Season 5 Patch 8} is BUGGED. It should be reduced by 50% in nightmare
		and by 75% in hell difficulty, instead it lasts full normal difficulty duration even in hell - only description
		changes. Compared to what it SHOULD be (1.5s +0.25s/lvl  in hell) this is a buff for hell difficulty (now 1.6s +0.4s/lvl).
		New duration is shorter compared to LoD (1.8s +0.5s/lvl in hell) , and we have smaller radius,
		but we also reduce monster AR so i think it's ok. )

	fixed cold mastery displaying wrong amount of cold pierce in description (PD2 bug)
		(badly softcoded in PD2 - fixed)

	cold mastery cold pierce changed from 5+1/lvl,45 cap to 6+2/lvl, no cap
		(still much worse than LoD where if you have a lot +skills you can skip investing a lot of points into this mastery
		,also i feel like a mercenary should NOT have better -res than a sorceress)

	fire mastery fire pierce changed from 1/lvl,30 cap to 3+1/lvl, no cap
		(50% of cold pierce sounds fair, ,also i feel like a mercenary should NOT have better -res than a sorceress)

	fixed static field displaying wrong amount of -res in description {it actually never goes below -40 -res (capped)}

	sorceress static field -resist progress now -1/lvl at all levels (now -40 at lvl 39 , was -40 at lvl 56)
		{ sorceress static field has a cap of -40 -res , PD2 wiki is WRONG, skill description showing
		in PD2 below -40 -res (lvl58+) is WRONG because of bad softcoding in description - fixed } 
		{ mercenary static field unchanged }
		(again i don't think a mercenary should have a better version of static field than a sorceress,
		i will not mess with maximum -res from active skills because breaking immunities will be too easy)
	
	sorceress static field duration changed from 5s to 5s+0.2s/lvl
	sorceress static field radius cap removed
		( lvls should give us something after lvl 39 )

	added radius in description for fireball (because it does NOT scale, it's always at LoD value of 2.66y - PD2 WIKI IS WRONG,
		someone who put this "scaling" there looked at aurarangecalc stat in skills.txt and didn't bother to test if it does anything.
		Turns out it's useless and actual radius is in missiles.txt in fireball missle and it's at range 4 (2.66y) there and never changes.
		So fireball explosion radius was NOT buffed compared to LoD, PD2 wiki is... again... WRONG.
		At this point will not look at PD2 WIKI as a valid source of information. Instead i will test stuff myself.
		Was wondering why a huge buff like that was never mentioned in patchnotes. Well because it NEVER HAPPENED!)

	assassin elemental traps and sorceress hydras now benefit from -%ElementalPierce at 25% (4% pierce=1% pierce for trap/hydra)
		{ that includes deathSentry Corpse explosion dmg }
		( complete removal of this was a huge overnerf imo, and -%ELE being useless for hydras from fire mastery is pure trolling.
		Buffing this to 50% makes selfcast skills feel weak in comparison, 25% makes -%ELE not completely useless but stil not
		that op, without this monsters with high res feel like immune. )

	sorceress shiver/chilling armor now start at 300s duration
	sorceress energy shield/thunder storm now start at 300s duration
		( buffing duration for buffs, no one wants to recast passives every 2-3 minutes, not fun )

	sorceress blaze duration now uncapped (from 8s cap)
		( a small buff, if we invest into mobility skill we should MOVE, not stand still every 8s )

	paladin prayer aura mana cost REMOVED
		( this maybe was strong vs diablo clone when he didn't summon quadrilion supersonic speed skeletons,
		now not so much imo, also imo auras shouldn't cost mana )

	paladin minimum sacrifice dmg to self now 1% (from 3%)
		( with 3% if we hit for 10k we drop 300? ouch... imo 100 is still a lot )

	assassin charged bolt sentry description now shows shots fired (it's 5+1 per 4baselvl of lightning sentry, 10 max)
		( that was interesting. I think shots fired for this skill is hardcoded or something, no amount of change
		in skills.txt was doing anything, it's like in original LoD 5+{(baselevel of lightning sentry)/4} no matter what.
		Yes, it's like that {as of s5 Patch #8} in online servers. )
		


MIRROR, ethVIAL, UNLIMITED KEY drop chance improved

	(Added chance to find: -same as ZOD RUNE {FOR EVERY ZOD YOU FIND you will also find 1 mirror, vial and key on average}.
	Put in rune droptable so if a ZOD can't drop MIRROR/VIAL/KEY can't drop from this.
	Added ON TOP OF hardcoded chance, so you still can find a mirror in act 1 norm {gl with that lmao}
	Still very rare, but at least now they potentially EXIST, AND YOU CAN CRAFT WITH IT, not just a trophy because everything feels
	"not rare enough" to mirror/eth vial)

CORRUPTION chance rebalance-now every corruption has "equal" chance FROM a group, so if it rolls sockets for example you have 1/6 chance to have 6 sockets

	(So you don't have to find 100 shacos to have +3 shaco. still very hard to minmax items but at least not totally impossible for SSF)

Monsters have X% Deadly Strike map corruption REMOVED

	(monsters able to crit is too unpredictable for me to be fun, i want monster dmg to be consistent
	and not be surprised by a random crit. monster dmg is giga buffed with mapmods compared to LoD. REMOVED)

QOL: now you can cube multiple flawless gems into perfect gems

	so we don't break our wrists, credit to BetweenWalls, i yoinked it from his CubeMain.txt , hope he doesn't mind i saved like 2hr of my time. ty ty

act bosses are always "quest bugged"

	(i noticed people don't like act boss farming
	in PD2 that much, i guess it's not as good as farming maps, so i decided
	to buff it a bit by giving them droptable of quest versions. Now every
	act boss kill will give you same drops as quest act boss kill)

skill shrine removed {due to a bug in PD2}

	(skill shrine is bugged in PD2 with skills that give flat hp boost
	{makes annoying hp glitch where our HP globe never goes back to correct value
	after shrine runs out-so it looks like we are never full hp until save+exit}
	so i set mininum area level for spawn to 200-in theory it will remove it completely)


And that's it. Now the game is PLAYABLE for old noskill people like me

every change was made so that you can switch between this and normal PD2 safely (no stat/item changes/lvlup changes etc. that would brick your char/make it different from original PD2 permanently) 
